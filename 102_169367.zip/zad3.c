#include <stdio.h>
#include <stdlib.h>

void foo(int * a, int * b){
    int temp;
    if(*a > *b){
        temp = *a;
        *a = *b;
        *b = temp;
    }
    else if(*b > *a){
        temp = *b;
        *b = *a;
        *a = temp;
    }
}

int main()
{
    int a = 4, b = 5;
    foo(&a,&b);
    printf("%d %d\n", a, b);
    int c = 10, d = 9;
    foo(&c,&d);
    printf("%d %d\n", c,d);
    return 0;
}

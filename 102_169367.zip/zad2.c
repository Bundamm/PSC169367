#include <stdio.h>
#include <stdlib.h>



float foo(unsigned int n){
    float pow = 1;
    for(int i = 1; i <= n; i++){
        pow *= 7;
    }
    return 1/(pow);
}

int main()
{
    int n = 3;
    printf("%f", foo(n));
    int m = 4;
    printf("%f", foo(m));
    return 0;
}
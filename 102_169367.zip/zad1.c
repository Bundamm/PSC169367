#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tab[] = {1, -1, 5, -5, 5, 8, 7};
    int *wsk=tab;
    int b = *(wsk+=2); //b=5
    int c = b+2; // b=5  , c=7
    int d = (b/=-6) ^ (c-=-2); // b=0  , c=9  , d=9
    int e = (wsk+=-1)[2]; // b=0  , c=9  , d=9  , e=-5
    e = (d *= 8) + (c /= 3); // b=0  , c=3  , d=72  , e=75
    c = d - (b+=8); // b=8  , c=64  , d=72  , e=75
    b = *wsk + e; // b=74  , c=64  , d=72  , e=75
    d = b * c % e; // b=74  , c=64  , d=11  , e=75
    return 0;
}

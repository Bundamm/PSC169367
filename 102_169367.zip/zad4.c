#include <stdio.h>
#include <stdlib.h>

int foo(unsigned int n){
    if(n == 0) return 4;
    if(n == 1) return -12;
    return foo(n-2) * 9;
}

int main()
{
    int n = 2, m = 3;
    printf("%d\n", foo(n));
    printf("%d\n", foo(m));
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

void foo(int n, int * tab1, int * tab2){
    for(int i = 0; i < n; i++){
        *(tab2+i) = *(tab1+i);
    }
    for(int i = 0; i < n-1; i++){
        for(int j = 0; j < n-i-1; j++){
            if(*(tab2+j) < *(tab2+j+1)){
                int temp = *(tab2+j);
                *(tab2+j) = *(tab2+j+1);
                *(tab2+j+1) = temp;
            }
        }
    }
}


void wyswietltab(int n, int * tab){
    for(int i = 0; i< n; i++){
        printf("%d\n", *(tab+i));
    }
}

int main()
{
    int n = 5;
    int * tab1 = (int*)malloc(n * sizeof(int));
    *(tab1) = 1;
    *(tab1+1) = 1;
    *(tab1+2) = 3;
    *(tab1+3) = 2;
    *(tab1+4) = 4;
    int * tab2 = (int*)malloc(n* sizeof(int));
    foo(n, tab1, tab2);
    wyswietltab(n, tab2);
    return 0;
}

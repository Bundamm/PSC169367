#include <stdio.h>
#include <stdlib.h>

int foo(char napis[], char c){
    int i = 0, counter = 0;
    if(napis[i] == '\0') return counter;
    for(i = 0; napis[i] !='\0'; i++){
        if(napis[i] == c) counter++;
    }
    return counter;
}

int main()
{
    char nap[] = "";
    char c = 'a';
    printf("%d\n", foo(nap,c));
    return 0;
}

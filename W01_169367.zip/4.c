#include <stdio.h>

union XYZ {
    int a;
    char b;
};

struct lista{
    union XYZ zaw;
};

int main() {
    struct lista tab[6];

    tab[0].zaw.b = 'a';
    tab[1].zaw.b = 'b';
    tab[2].zaw.b = 'c';
    tab[3].zaw.b = 'd';
    tab[4].zaw.b = 'e';
    tab[5].zaw.b = 'f';
    for (int i = 0; i < 6; i++) {
        printf("Element %d: a = %d, b = %c\n", i, tab[i].zaw.b, tab[i].zaw.b);
    }
    return 0;
}

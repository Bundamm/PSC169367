#include <stdio.h>
#include <stdlib.h>

int foo(int **tab, int n){
    int cur = 0;
    int curi = 0;
    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if(*(*(tab+i)+j) >= cur){
                cur = *(*(tab+i)+j);
                curi = i;
            }

        }
    }
    return curi;
}

int main()
{
    int n = 3;
    int **tab = (int**)malloc(sizeof(int*)*n);
    tab[0] = (int*)malloc(sizeof(int)*n);
    tab[1] = (int*)malloc(sizeof(int)*n);
    tab[2] = (int*)malloc(sizeof(int)*n);
    *(*(tab)) = 1;
    *(*(tab)+1) = 2;
    *(*(tab)+2) = 4;
    *(*(tab+1)) = 1;
    *(*(tab+1)+1) = 5;
    *(*(tab+1)+2) = 7;
    *(*(tab+2)) = 1;
    *(*(tab+2)+1) = 5;
    *(*(tab+2)+2) = 7;
    printf("%d\n", foo(tab, n));
    return 0;
}
